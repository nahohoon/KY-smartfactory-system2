// KY 재고관리 시스템 v4.0 — GAS 백엔드
var SHEET_TX      = '입출고이력';
var SHEET_MASTER  = '품목마스터';
var SHEET_CONFIG  = '시스템설정';
var SHEET_LOG     = '오류로그';

function doGet(e){
  var result;
  try{
    ensureSheets();
    var action=e&&e.parameter&&e.parameter.action?e.parameter.action:'test';
    if(action==='test')              result=doTest();
    else if(action==='getTransactions')   result=getTx();
    else if(action==='saveTransaction')   result=saveTx(e);
    else if(action==='getMasterItems')    result=getMasterItems();
    else if(action==='saveMasterItem')    result=saveMasterItem(e);
    else if(action==='deleteMasterItem')  result=deleteMasterItem(e);
    else if(action==='getDashboard')      result=getDashboard();
    else if(action==='getConfig')         result=getConfig();
    else if(action==='saveConfig')        result=saveConfig(e);
    else result={success:false,message:'알 수 없는 action: '+action};
  }catch(ex){
    logError(action||'unknown',ex);
    result={success:false,message:ex.toString()};
  }
  return ContentService.createTextOutput(JSON.stringify(result))
    .setMimeType(ContentService.MimeType.JSON);
}

function ensureSheets(){
  var ss=SpreadsheetApp.getActiveSpreadsheet();
  [[SHEET_TX,['ID','일시','유형','품목코드','품목명','수량','창고','담당자','현장','입고단가','출고단가','메모']],
   [SHEET_MASTER,['품목코드','품목명','규격','단위','안전재고','설명','등록일']],
   [SHEET_CONFIG,['키','값','수정일']],
   [SHEET_LOG,['일시','action','오류']]
  ].forEach(function(s){
    if(!ss.getSheetByName(s[0])){
      var sh=ss.insertSheet(s[0]);sh.appendRow(s[1]);
      sh.getRange(1,1,1,s[1].length).setFontWeight('bold').setBackground('#e8f0fe');
    }
  });
}
function logError(action,ex){
  try{SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_LOG)
    .appendRow([new Date(),action,ex.toString()]);}catch(e){}
}
function doTest(){
  var ss=SpreadsheetApp.getActiveSpreadsheet();
  return {success:true,message:'KY 시트 연결 정상 ('+ss.getName()+')',
    sheets:ss.getSheets().map(function(s){return s.getName();})};
}
function getTx(){
  var sh=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_TX);
  var rows=sh.getDataRange().getValues();
  if(rows.length<=1)return{success:true,transactions:[]};
  var tx=rows.slice(1).map(function(r){
    return{id:r[0],date:r[1]instanceof Date?r[1].toISOString():String(r[1]),
      type:r[2],code:r[3],name:r[4],qty:Number(r[5]),wh:r[6],
      mgr:r[7],site:r[8],inPrice:Number(r[9]),outPrice:Number(r[10]),memo:r[11]};
  });
  return{success:true,transactions:tx};
}
function saveTx(e){
  var d=JSON.parse(e.parameter.data||'{}');
  var sh=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_TX);
  sh.appendRow([d.id,d.date,d.type,d.code,d.name,d.qty,d.wh,d.mgr,d.site,d.inPrice||0,d.outPrice||0,d.memo||'']);
  return{success:true,message:'저장 완료'};
}
function getMasterItems(){
  var sh=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_MASTER);
  var rows=sh.getDataRange().getValues();
  if(rows.length<=1)return{success:true,items:[]};
  var items=rows.slice(1).map(function(r){
    return{code:r[0],name:r[1],spec:r[2],unit:r[3],safety:Number(r[4]),desc:r[5]};
  });
  return{success:true,items:items};
}
function saveMasterItem(e){
  var d=JSON.parse(e.parameter.data||'{}');
  var sh=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_MASTER);
  var rows=sh.getDataRange().getValues();
  for(var i=1;i<rows.length;i++){
    if(rows[i][0]===d.code){
      sh.getRange(i+1,1,1,7).setValues([[d.code,d.name,d.spec,d.unit,d.safety||0,d.desc||'',new Date()]]);
      return{success:true,message:'수정 완료'};
    }
  }
  sh.appendRow([d.code,d.name,d.spec,d.unit,d.safety||0,d.desc||'',new Date()]);
  return{success:true,message:'추가 완료'};
}
function deleteMasterItem(e){
  var code=e.parameter.code;
  var sh=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_MASTER);
  var rows=sh.getDataRange().getValues();
  for(var i=1;i<rows.length;i++){
    if(rows[i][0]===code){sh.deleteRow(i+1);return{success:true};}
  }
  return{success:false,message:'품목 없음'};
}
function getDashboard(){
  var txResult=getTx();var masterResult=getMasterItems();
  return{success:true,transactions:txResult.transactions,items:masterResult.items};
}
function getConfig(){
  var sh=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_CONFIG);
  var rows=sh.getDataRange().getValues();
  var obj={};rows.slice(1).forEach(function(r){if(r[0])obj[r[0]]=r[1];});
  return{success:true,config:obj};
}
function saveConfig(e){
  var d=JSON.parse(e.parameter.data||'{}');
  var sh=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_CONFIG);
  Object.keys(d).forEach(function(k){
    var rows=sh.getDataRange().getValues();var found=false;
    for(var i=1;i<rows.length;i++){if(rows[i][0]===k){sh.getRange(i+1,2).setValue(d[k]);sh.getRange(i+1,3).setValue(new Date());found=true;break;}}
    if(!found)sh.appendRow([k,d[k],new Date()]);
  });
  return{success:true};
}

# 📦 Smart Inventory Pro v4.0 — 운영형 (KY)

> **config.json 자동설정형 운영 버전**
> URL 접속만으로 어디서든 동일 설정 자동 적용

---

## 🏗️ 설정 구조 (config.json 방식)

```
┌─────────────────────────────────────────┐
│            배포 서버 (Vercel)            │
│                                         │
│  index.html   ← 앱 본체 (수정 불필요)  │
│  config.json  ← ★ 이것만 수정하면 됨  │
│  manifest.json                          │
│  Code.gs      ← Google Apps Script     │
└─────────────────────────────────────────┘
           ↓ 접속 시 자동 로드
    GAS URL, 회사명, 창고명, 계정 등 자동 적용
```

---

## ⚙️ config.json 수정법

```json
{
  "companyName": "KY 재고관리 시스템",   ← 회사명
  "logo": "KY",                           ← 로고 텍스트
  "gasUrl": "https://script.google.com/macros/s/.../exec",  ← GAS URL
  "warehouses": ["성서공장","현풍공장"],  ← 창고 목록
  "users": [
    {"id":"admin","pw":"비밀번호","name":"관리자","role":"admin"}
  ]
}
```

---

## 🏭 고객사 복제 방법 (15분)

```
1. config.template.json → config.json으로 복사
2. companyName, logo, gasUrl, warehouses, users 수정
3. GitHub 저장소 Fork → 파일 교체
4. Vercel 새 프로젝트로 배포
5. 고객사 전용 URL 발급 완료
```

---

## 🔗 GAS 연동 (Code.gs)

```
1. Google Sheets 새 문서 생성
2. 확장프로그램 → Apps Script
3. Code.gs 내용 붙여넣기 → 저장
4. 배포 → 웹 앱 (액세스: 모든 사용자)
5. 배포 URL → config.json의 gasUrl에 입력
6. GitHub Push → Vercel 자동 재배포 → 완료
```

---

## 🚀 Vercel 배포

```bash
# GitHub 연동 후 자동 배포 (권장)
# 또는 CLI:
npm i -g vercel && vercel --prod
```

Framework: **Other** (빌드 명령어 모두 비워두기)

---

## 🔑 기본 계정 (config.json 수정 필수)

| ID | PW | 역할 |
|----|----|----|
| admin | ky2026! | 관리자 |
| staff | ky_staff1 | 직원 |
| viewer | ky_view1 | 조회 |

---

Copyright © 2026 Smart Inventory Pro. All Rights Reserved.
